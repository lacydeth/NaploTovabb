﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp4
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string fileName = "naplo.csv";
        List<Osztalyzat> jegyek = new List<Osztalyzat>();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void OsztalyzatBetolt(string fileName)
        {
            jegyek.Clear();
            StreamReader sr = new StreamReader(fileName);
            while (!sr.EndOfStream)
            {
                string[] mezok = sr.ReadLine().Split(";");

                Osztalyzat ujJegy = new Osztalyzat(mezok[0], mezok[1], mezok[2], int.Parse(mezok[3]));

                jegyek.Add(ujJegy);
            }
            sr.Close();
            dgJegyek.ItemsSource = jegyek;
            MessageBox.Show("Az állomány beolvasása befejeződött!");
        }

        private void sliJegy_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lblJegy.Content = sliJegy.Value;
        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {
            using StreamWriter writer = new StreamWriter(fileName, append: true) ;
            {
                writer.WriteLine($"{txtNev.Text.ToString()} ; {cboTantárgy.Text} ; {dpDatum.Text.ToString()} ; {sliJegy.Value}");
                writer.Close();
            }
        }

        private void btnBetolt_Click(object sender, RoutedEventArgs e)
        {
            OsztalyzatBetolt(fileName);
        }
    }
}
